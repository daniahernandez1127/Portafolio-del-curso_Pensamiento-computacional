﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L4___DGHT_1152026
{
    internal class Ejercicio6
    {
        public static void Ejecutar()
        {
            Console.WriteLine(" ------------------------------------------------------------");
            double pi = 3.14159265;
            string cadena = pi.ToString("F2");

            Console.WriteLine("El valor decimal es: " + pi);
            Console.WriteLine("El valor decimal a texto es: " + cadena);

        }
    }
}
