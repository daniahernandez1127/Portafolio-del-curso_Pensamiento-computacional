﻿using L4___DGHT_1152026;
using System;
class Ejercicio1
{
    //Inicio de programa
    static void Main()
    {
        // 1. Declaracion de variables
        string nombre;
        int nivel;
        float puntosDeVida;
        bool esUnJefe;

        Console.WriteLine("Ingrese su nombre: ");
        nombre = Console.ReadLine(); //leyendo nombre

        Console.WriteLine("Ingrese su nivel: ");
        nivel = int.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese sus puntos de vida: ");
        puntosDeVida = float.Parse(Console.ReadLine());

        Console.WriteLine("Usted es un jefe o no? Escriba 'true' para verdadero o 'false' para falso: ");
        esUnJefe = bool.Parse(Console.ReadLine());
        if (esUnJefe == true)
        {
            Console.WriteLine("Usted es un jefe. ");
        }
        else
        {
            Console.WriteLine("Usted no es un jefe. ");
        }
        Console.WriteLine(" ------------------------------------------------------------");
        Console.WriteLine("Nombre del personjae: " + nombre);
        Console.WriteLine("Su nivel es: " + nivel);
        Console.WriteLine("Sus puntos de vida son: " + puntosDeVida);
        Console.WriteLine("Usted es un jefe o no? : " + esUnJefe);
        Console.WriteLine(" ------------------------------------------------------------");

        Ejercicio2.Ejecutar();
        Ejercicio3.Ejecutar();
        Ejercicio4.Ejecutar();
        Ejercicio5.Ejecutar();
        Ejercicio6.Ejecutar();
        Ejercicio7.Ejecutar();
    }
}
