﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L4___DGHT_1152026
{
    internal class Ejercicio5
    {
        public static void Ejecutar()
        {
            Console.WriteLine(" ------------------------------------------------------------");
            string valorDecimal = "25.5";
            double numeroDecimal = Convert.ToDouble(valorDecimal);

            Console.WriteLine("El valor decimal en texto es: " + valorDecimal);
            Console.WriteLine("El valor convertido a double es: " + numeroDecimal);

        }
    }
}
