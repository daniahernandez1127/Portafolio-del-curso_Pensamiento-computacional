﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L4___DGHT_1152026
{
    internal class Ejercicio3
    {
        public static void Ejecutar()
        {


            double precioExacto = 45.89;
            int precioRedondeado;

            precioRedondeado = (int)precioExacto;

            Console.WriteLine("El precio exacto es : " + precioExacto);
            Console.WriteLine("El precio redondeado es de: " + precioRedondeado);

        }
    
    
    }

}
