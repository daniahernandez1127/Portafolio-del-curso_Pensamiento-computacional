﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L4___DGHT_1152026
{
    internal class Ejercicio4
    {
        public static void Ejecutar()
        {
            int numero;
            Console.WriteLine(" ------------------------------------------------------------");
            Console.WriteLine("Ingrese un número: ");
            numero = int.Parse(Console.ReadLine());

            int resultado = numero + 5;
            Console.WriteLine(" ------------------------------------------------------------");
            Console.WriteLine("El numero ingresado es: " + numero);
            Console.WriteLine("El numero ingresado + 5 es de: " + resultado);

        }
    }
}
