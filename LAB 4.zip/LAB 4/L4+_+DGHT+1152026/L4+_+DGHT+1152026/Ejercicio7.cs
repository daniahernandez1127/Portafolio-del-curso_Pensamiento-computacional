﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L4___DGHT_1152026
{
    internal class Ejercicio7
    {
        public static void Ejecutar()
        {
            Console.WriteLine(" ------------------------------------------------------------");
            Console.WriteLine("Ingrese el precio del producto: ");
            string entrada = Console.ReadLine();

            double precio = Convert.ToDouble(entrada);

            double iva = precio * 0.21;

            double total = precio + iva;

            int totalSinDecimales = (int)total;

            Console.WriteLine("El total a pagar es: " + totalSinDecimales);
        }
    }

}
