﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L4___DGHT_1152026
{
    internal class Ejercicio2
    {
        public static void Ejecutar()
        {
            int numeroEntero = 1500;
            long numeroLargo;
            numeroLargo = numeroEntero;

            double numeroDecimal;
            numeroDecimal = numeroLargo;
            Console.WriteLine(" ------------------------------------------------------------");
            Console.WriteLine("El valor final de 'numero decimal' es: " + numeroDecimal);
            Console.WriteLine(" ------------------------------------------------------------");

        }
    }
}
