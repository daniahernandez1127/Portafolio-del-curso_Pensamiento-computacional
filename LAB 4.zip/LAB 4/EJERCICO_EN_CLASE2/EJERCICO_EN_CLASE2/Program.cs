﻿using System;
class Program
{
    static void Main()
    {
        // Selección Simple --------------------------------------------------
        int edad = 70;
        double monto_a_pagar = 48.50;

        if (edad >= 65)
        {
            monto_a_pagar = monto_a_pagar * 0.90;
        }

        Console.WriteLine("El monto a pagar es: " + monto_a_pagar.ToString());
        Console.ReadLine();




        // Selección Doble ---------------------------------------------------
        double calificacion = 70.41;
        if (calificacion >= 65)
        {
            Console.WriteLine("El alumno aprobó la materia");
        }
        else
        {
            Console.WriteLine("El alumno reprobó la materia");
        }
        Console.ReadLine();

        // Selección Múltiple ---------------------------------------------------
        edad = 15;
        double precio_del_boleto = 48;

        if (edad < 18)
        {
            monto_a_pagar = precio_del_boleto * 0.85;
         
        }
        else if (edad >= 65)
        { 
            monto_a_pagar = precio_del_boleto * 0.90;
        }
        else
        {
            monto_a_pagar = precio_del_boleto;
        }   

        Console.WriteLine("El total de la factura del cine es: " + monto_a_pagar.ToString());
        Console.ReadLine();
    }
}

