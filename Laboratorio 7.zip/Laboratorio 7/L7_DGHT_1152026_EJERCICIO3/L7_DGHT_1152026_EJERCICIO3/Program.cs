﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        int numero;
        int valor1= 0;  
        int valor2= 1;
        int temporal = 0;

                Console.WriteLine("Ingrese el numero de terminos de la serie Fibonacci: ");
                numero = int.Parse(Console.ReadLine());

                Console.Write("0 , 1 ");


                for (int i = 1; i <= numero; i++)
                {
                   temporal = valor1 + valor2;

                   Console.Write(" , " + temporal);

                    valor1 = valor2;
                    valor2 = temporal;
                 }



    }
}