﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        int numero;
        int contador = 1;

        Console.WriteLine("Ingrese un numero entero positivo:");
        numero = int.Parse(Console.ReadLine());

        do
        {
           
            if(numero % contador == 0)
            {
                Console.WriteLine(contador);
            }
            contador++;

        }
        while (contador <= numero);
    }
}