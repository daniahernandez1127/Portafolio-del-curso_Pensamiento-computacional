﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        
      
        for (int i = 1; i <= 12; i++)
        {
           

            Console.WriteLine(" Tabla del: " + i);


            for (int j = 1; j <= 10; j++) 
            {
                Console.WriteLine(  i + "*" + j + "=" + i*j);

            }
            

        }



    }
}