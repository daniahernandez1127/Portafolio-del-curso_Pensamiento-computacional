﻿using System;
class Program
{
        static void Main()
    {
        string nombre = "Dania Gabriela Hernández Tavic";
        int carnet = 1152026;
        int contador = 1;

        Console.WriteLine("Su nombre es: " + nombre + ", Su carnet es:" + carnet);

        while (contador <= 20)
        {
            if (contador % 2 == 0)
            {
                //Cambiar color de la letra a cyan
                Console.ForegroundColor = ConsoleColor.Cyan;
            }

            else
            {
                //Cambiar color  de la letra a verde
                Console.ForegroundColor = ConsoleColor.Green;

            }

            Console.WriteLine(contador);

            contador++;
        }
        Console.ForegroundColor = ConsoleColor.White;
        Console.ReadLine();




    }


}
