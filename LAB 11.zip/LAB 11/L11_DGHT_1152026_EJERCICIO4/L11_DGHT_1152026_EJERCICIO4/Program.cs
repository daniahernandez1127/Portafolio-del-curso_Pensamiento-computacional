﻿using System;

class Ejercicio4_Planilla
{
    static void Main()
    {
        // Arreglos dados
        string[] nombres = { "Ana", "Mario", "Saúl", "Karla", "María", "José" };
        double[] salario_x_hora = { 100, 125.50, 98.65, 125, 132.50, 102.50 };
        double[] horas_laboradas = new double[6];

        // Pedir horas al usuario
        for (int i = 0; i < nombres.Length; i++)
        {
            Console.Write("Ingrese horas trabajadas de " + nombres[i] + ": ");
            horas_laboradas[i] = double.Parse(Console.ReadLine());
        }

        Console.WriteLine("\n--- PAGOS SEMANALES ---");

        // Calcular pagos
        for (int i = 0; i < nombres.Length; i++)
        {
            double horas = horas_laboradas[i];
            double salario = salario_x_hora[i];
            double pago;

            if (horas <= 40)
            {
                pago = horas * salario;
            }
            else
            {
                double horasExtra = horas - 40;
                pago = (40 * salario) + (horasExtra * salario * 1.5);
            }

            Console.WriteLine(nombres[i] + ": Q" + pago);
        }
    }
}