﻿using System;

class Ejercicio3_Calificaciones
{
    static void Main()
    {
        int[] numeros = new int[10];
        Random rnd = new Random();
        int opcion;

        // Generar números aleatorios entre 50 y 100
        for (int i = 0; i < numeros.Length; i++)
        {
            numeros[i] = rnd.Next(50, 101);
        }

        do
        {
            Console.WriteLine("\n Bienvenido al menú de calificaciones");
            Console.WriteLine("\nSeleccione una opción");

            Console.WriteLine("1. Reporte de rendimiento");
            Console.WriteLine("2. Estadísticas");
            Console.WriteLine("3. Salir");
            Console.Write("Seleccione una opción: ");

            opcion = int.Parse(Console.ReadLine());

            if (opcion == 1)
            {
                Console.WriteLine("\nReporte de rendimiento:\n");

                for (int i = 0; i < numeros.Length; i++)
                {
                    int nota = numeros[i];

                    // Asignar color según el rango
                    if (nota >= 50 && nota <= 64)
                    {
                        Console.ForegroundColor = ConsoleColor.Magenta;
                    }
                    else if (nota >= 65 && nota <= 79)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                    }
                    else if (nota >= 80 && nota <= 100)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }

                    Console.Write(nota + " ");
                }

                Console.ResetColor(); // regresar color normal
                Console.WriteLine();
            }
            else if (opcion == 2)
            {
                int suma = 0;
                int mayor = numeros[0];
                int menor = numeros[0];

                for (int i = 0; i < numeros.Length; i++)
                {
                    suma += numeros[i];

                    if (numeros[i] > mayor)
                    {
                        mayor = numeros[i];
                    }

                    if (numeros[i] < menor)
                    {
                        menor = numeros[i];
                    }
                }

                double promedio = (double)suma / numeros.Length;

                Console.WriteLine("\nEstadísticas:");
                Console.WriteLine("Promedio: " + promedio);
                Console.WriteLine("Mayor: " + mayor);
                Console.WriteLine("Menor: " + menor);
            }

        } while (opcion != 3);

        Console.WriteLine("\nPrograma finalizado.");
    }
}