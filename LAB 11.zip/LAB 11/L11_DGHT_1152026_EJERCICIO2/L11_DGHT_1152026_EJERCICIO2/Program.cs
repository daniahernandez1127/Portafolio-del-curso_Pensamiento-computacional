﻿using System;

class Ejercicio2_TraduccionPalabras
{
    static void Main()
    {
        int opcion;

        string[] español = { "rojo", "azul", "amarillo", "blanco", "verde" };
        string[] inglés = { "red", "blue", "yellow", "white", "green" };
        string[] italiano = { "rosso", "blu", "giallo", "bianco", "verde" };

        do
        {
            Console.WriteLine("Bienvenido al menú de traducción de palabras.");
            Console.WriteLine("Seleccione el número de opción que desea realizar:");
            Console.WriteLine("1. Practicar lección");
            Console.WriteLine("2. Terminar lección");
            Console.WriteLine("-------------------------------");

            opcion = int.Parse(Console.ReadLine());

            if (opcion == 1)
            {
                Console.WriteLine("Ingrese una palabra en español para traducir al inglés e italiano:");
                string palabra = Console.ReadLine().ToLower();

                int posicion = -1;

                // Buscar la palabra en el arreglo
                for (int i = 0; i < español.Length; i++)
                {
                    if (palabra == español[i])
                    {
                        posicion = i;
                        break;
                    }
                }

                // Mostrar resultado
                if (posicion != -1)
                {
                    Console.WriteLine(
                        español[posicion] + ", " +
                        inglés[posicion] + ", " +
                        italiano[posicion]
                    );
                }
                else
                {
                    Console.WriteLine("La palabra no corresponde a la lección actual");
                }
            }

        } while (opcion != 2);

        Console.WriteLine("Programa finalizado.");
    }
}