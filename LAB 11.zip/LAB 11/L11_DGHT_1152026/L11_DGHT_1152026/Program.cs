﻿using System;

class Ejercicio1_Palindromo
{
    static void Main()
    {
        Console.Write("Ingrese una palabra: ");
        string palabra = Console.ReadLine();

        string palabraPalindromo = "";

        // Convertir a minúsculas
        palabra = palabra.ToLower();

        // Recorrer de derecha a izquierda
        for (int i = palabra.Length - 1; i >= 0; i--)
        {
            palabraPalindromo += palabra[i];
        }

        // Comparar
        if (palabra == palabraPalindromo)
        {
            Console.WriteLine("¿Es palíndromo?: Sí");
        }
        else
        {
            Console.WriteLine("¿Es palíndromo?: No");
        }
    }
}