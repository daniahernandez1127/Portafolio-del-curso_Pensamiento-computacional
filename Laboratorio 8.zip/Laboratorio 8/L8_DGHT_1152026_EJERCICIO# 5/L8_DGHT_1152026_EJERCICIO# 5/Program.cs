﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        int numeroFilas = 0;
        

        Console.WriteLine("Ingrese numero de filas:  ");
        numeroFilas= int.Parse(Console.ReadLine());

        for(int i = 1; i <= numeroFilas; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                if (j != i)
                {
                    Console.Write(" * ");
                }
                else
                {
                    Console.WriteLine(" * ");
                }
            }
           
        }   

    }
}
