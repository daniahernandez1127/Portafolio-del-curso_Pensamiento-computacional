﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        int numero;
        int mayor = 0;
        int menor = 0;
        int suma = 0;
        int promedio;

        for (int i = 1; i <= 20; i++)
        {
            Console.WriteLine("Ingrese el numero: " +i);
            numero = int.Parse(Console.ReadLine());


            if( i == 1)
            {
                mayor = numero;
                menor = numero;
                suma = numero;
            }

            else
            {
                if (numero > mayor)
                {
                    mayor = numero;
                }
                else if( numero < menor )
                {
                    menor = numero;

                }

                suma = suma + numero;

            }

        } //Cierre del for 
        promedio = suma / 20;

        Console.WriteLine("El numero mayor es :" + mayor);
        Console.WriteLine("El numero menor es :" + menor);
        Console.WriteLine("La sumatoria  es :" + suma);
        Console.WriteLine("El promedio es :" + promedio);





    }
}
