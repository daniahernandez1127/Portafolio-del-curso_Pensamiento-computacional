﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
       int numeroEntero = 0;
       int opcion = 0;

        Console.WriteLine("Ingrese un numero entero: ");
        numeroEntero = int.Parse(Console.ReadLine());

        Console.WriteLine("Seleccione una opcion: ");
        Console.WriteLine("1. Mostrar los números desde el número ingresado hasta 1. ");
        Console.WriteLine("2. Mostrar los múltiplos de 3 hasta el número ingresado. ");
        Console.WriteLine("3. Mostrar los múltiplos de 5 hasta el número ingresado ");

        opcion = int.Parse(Console.ReadLine());

        if ( opcion == 1)
        {
            for (int i = numeroEntero; i >= 1; i--)
            {
                Console.WriteLine(i);
            }
        }

        else if (opcion == 2)
        {
            for (int i = 1; i <= numeroEntero; i++)
            {
                if (i % 3 == 0)
                {
                    Console.WriteLine(i);
                }
            }
        }

        else if (opcion == 3)
        {
            for (int i = 1; i <= numeroEntero; i++)
            {
                if (i % 5 == 0)
                {
                    Console.WriteLine(i);
                }
            }
        }
         else
        {
            Console.WriteLine("Opcion no valida.");
        }   











    }
}
