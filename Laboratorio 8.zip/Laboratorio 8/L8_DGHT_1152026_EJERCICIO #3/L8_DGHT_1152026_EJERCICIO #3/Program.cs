﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        double montoCompra = 0;
        double descuento = 0;
        double totalAPagar = 0;
        int    clientesDescuento = 0;

        for (int i = 1; i <=  3; i++)
        {
            Console.WriteLine("Ingrese el monto de compra del cliente mumero: " + i);
            montoCompra = int.Parse(Console.ReadLine());

            if (montoCompra > 700)
            {
                descuento = montoCompra * 12 / 100;
                clientesDescuento++;
            }
            else if ( montoCompra > 300)
            {
                descuento = montoCompra * 5 / 100;
                clientesDescuento++;


            }

            totalAPagar = montoCompra - descuento;

            Console.WriteLine(" El total a pagar del cliente numero: " + i + " es: " + totalAPagar);
            descuento = 0;

        } //Cierre del for 

        Console.WriteLine("El total de clientes con descuento fueron : " + clientesDescuento);
        Console.WriteLine("El total de ventas del dia fueron : 10 " );




    }
}
