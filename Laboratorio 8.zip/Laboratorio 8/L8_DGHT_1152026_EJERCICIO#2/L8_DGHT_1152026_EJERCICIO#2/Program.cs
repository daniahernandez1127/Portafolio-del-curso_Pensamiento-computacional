﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void Main()
    {
        

        for (int i = 1; i <= 100; i++)
        {
            // Evaluando si es multiplo de 2
            if( i % 2 == 0 && i % 7 == 0 )
            {
                Console.WriteLine(i + " ParSiete");

            }
            else if  (i % 2 == 0)
            {
                Console.WriteLine(i + " par");

            }
            else if  (i % 7 == 0)
            {
                Console.WriteLine(i + " Siete");

            }
            else
            {
                Console.WriteLine(i);

            }

        } //Cierre del for 

    }
}
