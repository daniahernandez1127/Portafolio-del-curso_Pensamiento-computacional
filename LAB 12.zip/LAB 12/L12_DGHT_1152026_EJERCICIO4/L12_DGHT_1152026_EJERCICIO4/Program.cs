﻿using System;

class Ej
{
    // Declarar matrix cuadrada
    static int[,] matriz = new int[3,3 ];

    static void Main()
    {


        // Llenar la matriz
        Llenar();
        // Verificar si la matriz es simétrica
        if (EsSimetrica())
        {
            Console.WriteLine("La matriz es simétrica.");
        }
        else
        {
            Console.WriteLine("La matriz no es simétrica.");
        }   

    }


    //Procedimiento para llenar la matriz 
    static void Llenar()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                Console.Write($"Ingrese el valor [{i},{j}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

   //Funcion para  determinar si la matriz es simétrica con respecto al eje y
    static bool EsSimetrica()
    {
        int contador = 0;   
        for (int i = 0; i < 3; i++)
        {
            if(matriz[i, 0] != matriz[i, 2])
            {
                contador++;
            }
           
        }
        return true;
    }   

}

