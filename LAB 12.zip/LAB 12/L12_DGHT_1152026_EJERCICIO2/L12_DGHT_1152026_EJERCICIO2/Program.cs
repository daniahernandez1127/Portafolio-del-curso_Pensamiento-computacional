﻿using System;

class Ejercicio
{
    // Declarar matrix cuadrada
    static int[,] matriz = new int[4,6];

    static void Main()
    {


        // Llenar la matriz
        Llenar();
        // Mostrar la cantidad de números pares
        Console.WriteLine($"La cantidad de números pares es: {numerosPares()}");
        // Mostrar la cantidad de números impares
        Console.WriteLine($"La cantidad de números impares es: {numerosImpares()}"); 

    }


    //Procedimiento para llenar la matriz 
    static void Llenar()
    {
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                Console.Write($"Ingrese valor [{i},{j}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    //Funcion para numeros pares
    static int numerosPares()
    {
        int numerosPares = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                if (matriz[i, j] % 2 == 0)
                    numerosPares++;
            }
        }
        return numerosPares;
    }

    //Funcion para numeros impares
    static int numerosImpares()
    {
        int numerosImpares = 0;
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 6; j++)
            {
                if (matriz[i, j] % 2 != 0)
                    numerosImpares++;
            }
        }
        return numerosImpares;
    }


}

