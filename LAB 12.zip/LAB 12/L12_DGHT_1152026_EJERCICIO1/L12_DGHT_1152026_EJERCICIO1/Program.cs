﻿using System;

class Ejercicio
{
    // Declarar matrix cuadrada
    static int[,] matriz = new int[5, 5];

    static void Main()
    {
        

        // Llenar la matriz
        Llenar();
        // Mostrar la suma de la diagonal principal
       Console.WriteLine($"La suma de la diagonal principal es: {sumaDiagonalPrincipal()}");
        // Mostrar la suma de la diagonal secundaria
        Console.WriteLine($"La suma de la diagonal secundaria es: {sumaDiagonalSecundaria()}");


    }


    //Procedimiento para llenar la matriz 
    static void Llenar()
    {
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                Console.Write($"Ingrese valor [{i},{j}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    //Funcion para sumar la diagonal principal
    static int sumaDiagonalPrincipal()
    {
        int suma = 0;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (i== j)
                 suma= suma + matriz[i, j];  
             }
        }
        return suma;
    }

    //Funcion para sumar la diagonal secundaria
    static int sumaDiagonalSecundaria()
    {
        int suma = 0;
        for (int i = 0; i < 5; i++)
        {
            suma = matriz[i, 4 - i ] + suma;

        }
        return suma;
    }


}

