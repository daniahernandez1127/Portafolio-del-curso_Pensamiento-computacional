﻿using System;

class Ejercicio
{
    // Declarar matrix cuadrada
    static int[,] matriz = new int[5, 4];

    static void Main()
    {


        // Llenar la matriz
        Llenar();

        //Llamar a la funcion para mostrar el promedio de cada estudiante   
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine($"El promedio del estudiante {i} es: {promedioEstudiante(i)}");
        }

        //Llamar a la funcion para determinar si el estudiante aprobo o no
        for (int i = 0; i < 5; i++)
        {
            if (aprobo(i) == true)
            {
                Console.WriteLine($"El estudiante {i} aprobo.");
            }
            else
            {
                Console.WriteLine($"El estudiante {i} no aprobo.");
            }
        }
    }


    //Procedimiento para llenar la matriz 
    static void Llenar()
    {
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.Write($"Ingrese la nota [{i},{j}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    //Funcion para promedio de cada estudiante
    static double promedioEstudiante(int estudiante)
    {
        int suma = 0;
        for (int j = 0; j < 4; j++)
        {
            suma = suma+ matriz[estudiante, j];
        }
        return (double)suma / 4;
    }



    //Funcion para determinar si el estudiante aprobo o no
    static bool aprobo(int estudiante)
    {
        return promedioEstudiante(estudiante) >= 61;
    }



}

