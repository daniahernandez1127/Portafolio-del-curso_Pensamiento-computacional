﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void recibirDano( ref int puntosSalud)
    {
        if (puntosSalud - 5 >= 0)
        {
            puntosSalud -= 5;
            Console.WriteLine("El personaje ha recibido daño, puntos de salud restantes: " + puntosSalud);
        }
        else
        {
            Console.WriteLine("El personaje ha sido derrotado.");
        }
    }

    static void curar(ref int puntosSalud)
    {
      if ( puntosSalud + 3 <= 15)
        {             puntosSalud += 3;
            Console.WriteLine("El personaje ha sido curado, puntos de salud actuales: " + puntosSalud);
        }
        else
        {
            Console.WriteLine("El personaje ya tiene la salud máxima.");
        }
    }

    static void mostrarSalud(ref int puntosSalud)
    {
      
        if (puntosSalud >= 11 && puntosSalud <= 15)
        {
            Console.ForegroundColor = ConsoleColor.Green;
        }
        else if (puntosSalud >= 6 && puntosSalud <= 10)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
        }

        Console.WriteLine("Puntos de salud actuales: " + puntosSalud);
        Console.ResetColor();
    }

    static void calificarDesempeno(ref int puntosSalud, ref string calificacion )
    {

        if (puntosSalud == 15)
        {
            calificacion = "S";
        }
        else if (puntosSalud >= 11 && puntosSalud <= 14)
        {
            calificacion = "A";
        }
        else if (puntosSalud >= 6 && puntosSalud <= 10)
        {
            calificacion = "B";
        }
        else
        {
            calificacion = "C";
        }

        Console.WriteLine("Su calificacion es : " + calificacion);
       
    }


    static void Main()
    {

        int puntosSalud;
        string calificacion = "";
        Console.WriteLine("Ingrese los puntos de salud iniciales del personaje:" );
        puntosSalud = int.Parse(Console.ReadLine());

        recibirDano(ref puntosSalud);
        curar(ref puntosSalud);
        mostrarSalud(ref puntosSalud);
        calificarDesempeno(ref puntosSalud, ref calificacion);


    }


   
}


