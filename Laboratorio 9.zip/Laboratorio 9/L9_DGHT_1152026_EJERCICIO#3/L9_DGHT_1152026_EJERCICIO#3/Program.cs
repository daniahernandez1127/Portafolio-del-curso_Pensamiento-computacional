﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void CalcularDescuento(double porcentajeDescuento,ref double precioBoletos)
    {
        //Calcular el descuento
        double totalDescuento;
        totalDescuento = precioBoletos * porcentajeDescuento;

        //Restar el descuento al precio original
        precioBoletos = precioBoletos - totalDescuento;



    }
    static void Main()
    {
        double porcentajeDescuento = 0;
        double precioBoletos = 0;

        Console.WriteLine("Ingrese el porcentaje de descuento : ");
        porcentajeDescuento = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese el precio del boleto : ");
        precioBoletos = double.Parse(Console.ReadLine());


        Console.WriteLine("El porcentaje de descuento es: " + porcentajeDescuento);
        Console.WriteLine("El precio del boleto es : " + precioBoletos);

        //Llamar al Procedimiento para calcular el descuento
        CalcularDescuento(porcentajeDescuento,ref precioBoletos);

        //Mostrar el precio del boleto con el descuento aplicado
        Console.WriteLine("El precio del boleto con el descuento es : " + precioBoletos);




    }
}
