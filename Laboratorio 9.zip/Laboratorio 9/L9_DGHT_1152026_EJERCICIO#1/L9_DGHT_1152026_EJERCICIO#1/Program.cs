﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
   static void CantidadLetras(string palabra)
    {
        Console.WriteLine("La longitud de la palabra es: " + palabra.Length);
    }
    static void Main()
    {
        string palabra = "";
        Console.WriteLine("Ingrese una palabra : ");
        palabra = Console.ReadLine();

        CantidadLetras( palabra );
        

    }
}
