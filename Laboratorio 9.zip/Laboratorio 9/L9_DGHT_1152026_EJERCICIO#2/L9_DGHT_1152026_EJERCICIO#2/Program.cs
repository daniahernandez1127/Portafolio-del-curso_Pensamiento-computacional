﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;
class Program
{
    static void IntercambiarValores(ref int valorA, ref int valorB)
    {

       int temp = valorA;
        valorA = valorB;
        valorB = temp;

        Console.WriteLine("Intercambiando los valores...");

        Console.WriteLine("El valor de A es: " + valorA);
        Console.WriteLine("El valor de B es: " + valorB);

       
    }
    static void Main()
    {
        int valorA = 0;
        int valorB = 0;

        Console.WriteLine("Ingrese el valor para A : ");
        valorA = int.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese el valor para B : ");
        valorB = int.Parse(Console.ReadLine());


        Console.WriteLine("El valor de A es: " + valorA);
        Console.WriteLine("El valor de B es: " + valorB);

        IntercambiarValores(ref valorA, ref valorB);



    }
}
