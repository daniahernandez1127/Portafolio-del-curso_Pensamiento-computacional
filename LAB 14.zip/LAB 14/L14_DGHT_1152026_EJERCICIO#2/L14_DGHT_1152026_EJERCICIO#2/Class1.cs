﻿using System;
using System.Collections.Generic;
using System.Text;

namespace L14_DGHT_1152026_EJERCICIO_2
{
    internal class Class1
    {
    }
}
