﻿using System;

class Program
{
    static void Main()
    {
        // Crear producto 1
        Producto producto1 = new Producto(
            "Salsa de tomate",
            30,
            10
        );

        // Crear producto 2
        Producto producto2 = new Producto(
            "Ketchup",
            25,
            15
        );

        // Mostrar información inicial
        Console.WriteLine("=== PRODUCTO 1 ===");
        producto1.mostrarInformacion();

        Console.WriteLine();

        Console.WriteLine("=== PRODUCTO 2 ===");
        producto2.mostrarInformacion();

        // Realizar una venta
        Console.WriteLine("\n=== REALIZAR UNA VENTA ===");

        producto1.vender(5);
        producto2.vender(10);

        // Mostrar información después de la venta

        Console.WriteLine("\n=== INFORMACION DESPUES DE LA VENTA ===");
        producto1.mostrarInformacion();
        Console.WriteLine();

        producto2.mostrarInformacion();

        Console.WriteLine();


        Console.WriteLine("\n=== REABASTECER PRODUCTOS ===");

        producto1.reabastecer(10);
        producto2.reabastecer(5);

        Console.WriteLine("\n=== INFORMACION DESPUES DE REABASTECER ===");
        producto1.mostrarInformacion();
        Console.WriteLine();
        producto2.mostrarInformacion();


    }
}