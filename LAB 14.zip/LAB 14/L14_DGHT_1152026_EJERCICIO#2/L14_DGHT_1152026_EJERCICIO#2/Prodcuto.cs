﻿using System;

class Producto
{
    string nombre;
    double precio;
    int  cantidad;

    // Constructor
    public Producto(string nombre, double precio, int cantidad)
    {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Método para mostrar información
    public void mostrarInformacion()
    {
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Precio: Q" + precio);
        Console.WriteLine("Cantidad: " + cantidad);
    }

    // Método reabastecer
    public void reabastecer(int cantidadNueva)
    {
        this.cantidad = cantidad + cantidadNueva;
        Console.WriteLine("Reabastecimiento realizado. Nueva cantidad: " + cantidad);
    }

    // Método vender
    public void vender(int cantidadVendida)
    {
        if (cantidadVendida <= cantidad)
        {
            cantidad = cantidad - cantidadVendida;
            Console.WriteLine("Venta realizada correctamente.");
        }
        else
        {
            Console.WriteLine("Cantidad insuficiente para vender.");
        }
       
        
    }
}