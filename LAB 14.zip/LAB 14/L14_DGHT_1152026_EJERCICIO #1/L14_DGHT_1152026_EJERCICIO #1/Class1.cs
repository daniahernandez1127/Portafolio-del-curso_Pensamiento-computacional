﻿using System;

class CuentaBancaria
{
    string titular;
    string numeroCuenta;
    decimal saldo;

    // Constructor
    public CuentaBancaria(string titular, string numeroCuenta, decimal saldo)
    {
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }

    // Método para mostrar información
    public void mostrarInformacion()
    {
        Console.WriteLine("Titular: " + titular);
        Console.WriteLine("Número de cuenta: " + numeroCuenta);
        Console.WriteLine("Saldo: Q" + saldo);
    }

    // Método depositar
    public void depositar(decimal monto)
    {
        saldo= saldo + monto;
    }

    // Método retirar
    public void retirar(decimal monto)
    {
        if (monto <= saldo)
        {
            saldo = saldo -  monto;
            Console.WriteLine("Retiro realizado correctamente.");
        }
        else
        {
            Console.WriteLine("Fondos insuficientes.");
        }
    }
}