﻿using System;

class Program
{
    static void Main()
    {
        // Crear cuenta 1
        CuentaBancaria cuenta1 = new CuentaBancaria(
            "Dania Hernandez",
            "12345",
            3000
        );

        // Crear cuenta 2
        CuentaBancaria cuenta2 = new CuentaBancaria(
            "Gabriela Tavic",
            "45678",
            3500
        );

        // Mostrar información inicial
        Console.WriteLine("=== CUENTA 1 ===");
        cuenta1.mostrarInformacion();

        Console.WriteLine();

        Console.WriteLine("=== CUENTA 2 ===");
        cuenta2.mostrarInformacion();

        // DEPÓSITO
        Console.WriteLine("\n=== DEPÓSITO ===");

        Console.WriteLine("Saldo antes cuenta 1:");
        cuenta1.mostrarInformacion();

        cuenta1.depositar(500);

        Console.WriteLine("Saldo después cuenta 1:");
        cuenta1.mostrarInformacion();

        Console.WriteLine("-- INFORMACION CUENTA 2 --");

        Console.WriteLine("Saldo antes de la cuenta 2:");
        cuenta2.mostrarInformacion();

        cuenta2.depositar(500);

        Console.WriteLine("Saldo después de la cuenta 2:");
        cuenta2.mostrarInformacion(); 

        // RETIRO
        Console.WriteLine("\n=== RETIRO ===");

        Console.WriteLine("Saldo antes cuenta 1:");
        cuenta1.mostrarInformacion();

        cuenta1.retirar(1000);

        Console.WriteLine("Saldo después cuenta 1:");
        cuenta1.mostrarInformacion();

        Console.WriteLine("-- INFORMACION CUENTA 2 --"); 
        Console.WriteLine("Saldo antes cuenta 2:");
        cuenta2.mostrarInformacion();

        cuenta2.retirar(1000);

        Console.WriteLine("Saldo después cuenta 2:");
        cuenta2.mostrarInformacion();

    }
}