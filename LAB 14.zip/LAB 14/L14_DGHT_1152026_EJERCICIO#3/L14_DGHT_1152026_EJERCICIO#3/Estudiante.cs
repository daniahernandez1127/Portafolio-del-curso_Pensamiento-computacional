﻿using System;

class Estudiante
{
    public string nombre;
    public int edad;
    public string grado;
    public double[] notas;
    // Constructor
    public Estudiante(string nombre, int edad, string grado, double[] notas)
    {
        this.nombre = nombre;
        this.edad = edad;
        this.grado = grado;
        this.notas = notas;
    }
    // Método para mostrar información
    public void mostrarInformacion()
    {
        Console.WriteLine("Nombre: " + nombre);
        Console.WriteLine("Edad: " + edad);
        Console.WriteLine("Grado: " + grado);
        Console.WriteLine("Notas: " + string.Join(", ", notas));
    }

    // Método para calcular el promedio
    public double calcularPromedio()
    {
        double suma = 0;
        foreach (double nota in notas)
        {
            suma = suma + nota;
        }
        return suma / notas.Length;
    }

    // Método para determinar si el estudiante aprobó o no
    public string determinarAprobacion()
    {
        double promedio = calcularPromedio();
        if (promedio >= 61)
        {
            return "Aprobado";
        }
        else
        {
            return "Reprobado";
        }
    }

    // Método para añadir una nueva nota
    public void añadirNota(double nuevaNota)
    {
        Array.Resize(ref notas, notas.Length + 1);
        notas[notas.Length - 1] = nuevaNota;
    }

}





