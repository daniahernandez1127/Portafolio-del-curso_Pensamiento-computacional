﻿using System;

class Escuela
{
    static void Main()
    {
        // Crear estudiante 1
        Estudiante estudiante1 = new Estudiante(
            "Juan Pérez",
            12,
            "Primero Basico",
            new double[] { 85, 90, 78 }
        );

        // Crear estudiante 2
        Estudiante estudiante2 = new Estudiante(
            "Ana Gómez",
            12,
            "Primero Basico",
            new double[] { 75, 80, 70 }
        );

        // Mostrar información inicial
        Console.WriteLine("=== ESTUDIANTE 1 ===");
        estudiante1.mostrarInformacion();

        Console.WriteLine();

        Console.WriteLine("=== ESTUDIANTE 2===");
        estudiante2.mostrarInformacion();

        // Calcular el promedio y determinar la aprobación
        Console.WriteLine();
        Console.WriteLine( $"Promedio de {estudiante1.nombre}: {estudiante1.calcularPromedio():F2} - {estudiante1.determinarAprobacion()}" );
        Console.WriteLine();

        // Calcular el promedio y determinar la aprobación
        Console.WriteLine();
        Console.WriteLine($"Promedio de {estudiante2.nombre}: {estudiante2.calcularPromedio():F2} - {estudiante2.determinarAprobacion()}");

        //Añadir una nueva nota al estudiante 1
        estudiante1.añadirNota(92);
        estudiante1.mostrarInformacion();

        //Añadir una nueva nota al estudiante 2
        estudiante2.añadirNota(90);
        estudiante2.mostrarInformacion();

    }
}