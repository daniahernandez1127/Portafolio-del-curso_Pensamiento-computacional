﻿using System;
using System.ComponentModel.Design;
// Análisis del problema
//Entradas: Un año (entero).
//Procesos: Evaluar si el año cumple con la condición matematica de año bisiesto´.
//Salidas: Mostrar un mensaje indicando si el año es bisiesto o no lo es.
class Ejercicio1
{
    static void Main()
    {
        // Inicio de programa Ejercicio 2
        int año;
        Console.WriteLine("Ingrese un año: ");
        año = int.Parse(Console.ReadLine());

        if (año % 400 == 0)
        {
            Console.WriteLine("El año ingresado es bisiesto: " + año);
        }
        else if (año % 100 == 0)
        {
            Console.WriteLine("El año ingresado no es bisiesto: " + año);
        }
        else if (año % 4 == 0)
        {
            Console.WriteLine("El año ingresado es bisiesto: " + año);
        }
        else
        {
            Console.WriteLine("El año ingresado no es bisiesto: " + año);

            Console.WriteLine("---------------------------------------------------");




        }
    }
}