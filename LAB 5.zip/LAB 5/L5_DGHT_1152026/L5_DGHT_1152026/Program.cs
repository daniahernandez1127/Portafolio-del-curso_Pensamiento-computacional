﻿using System;
using System.ComponentModel.Design;

// Análisis del problema
// Entradas: Un número entero ingresado por el usuario.
//Proceso: : Leer el número, evaluar si el número es mayor que 0, si no, evaluar si es menor que 0, si no cumple ninguna de las anteriores, entonces es cero.
//Salidas: Mostrar un mensaje indicando si el número es positivo, negativo o cero.
class Ejercicio1
{
    //Inicio de programa Ejercicio 1
    static void Main()
    {
        int numero;
        Console.WriteLine("Ingrese un número entero: ");
        numero = int.Parse(Console.ReadLine());

        if (numero > 0)
        {
            Console.WriteLine("El número ingresado es positivo: " + numero);
        }
        else if (numero < 0)
        {
            Console.WriteLine("El numero Ingresado es negativo: " + numero);
        }
        else
        {
            Console.WriteLine("El numero ingresado es cero: " + numero);
        }

        Console.WriteLine("---------------------------------------------------");

       

        
    }
}