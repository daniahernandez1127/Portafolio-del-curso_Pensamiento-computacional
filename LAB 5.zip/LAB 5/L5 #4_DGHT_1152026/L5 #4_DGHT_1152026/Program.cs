﻿//Análisis del problema
//Entradas: 
//- Horas estacionado
//- Monto ingresado
//Procesos:
//Leer la cantidad de horas que estuvo estacionado.
//Calcular el total a pagar (horas * 10).
//Leer el monto ingresado por el usuario.
//Comparar el monto ingresado con el total a pagar.
//- Si el monto ingresado es menor que el total a pagar, mostrar un mensaje de error indicando que los fondos no son suficientes.
//- Si el monto ingresado es igual al total a pagar, mostrar un mensaje indicando que no se requiere cambio.
// - Si el monto ingresado es mayor que el total a pagar, calcular el cambio a devolver y desglosarlo en billetes de $100, $50, $20, $10, $5 y $1.
//Mostrar el cambio total a devolver y el desglose de billetes.
//Salidas:
//Total a pagar.
//Mensaje de error si los fondos no son suficientes.
//Mensaje indicando que no se requiere cambio si el monto ingresado es igual al total a pagar..
//Cambio total a devolver y desglose de billetes si el monto ingresado es mayor que el total a pagar.




using System;
using System.ComponentModel.Design;
class Ejercicio1
{
    //Inicio de programa Ejercicio 4
    static void Main()
    {
       int horas;
        int MontoIngresado;
        int TotalPagar;
        int cambio;
        int Billete100 = 0;
        int Billete50 = 0;
        int Billete20 = 0;
        int Billete10 = 0;
        int Billete5 = 0;
        int Billete1 = 0;


        Console.WriteLine("Ingrese la cantidad de horas que estuvo estacionado: ");
        horas = int.Parse(Console.ReadLine());

        Console.WriteLine("Su total a pagar es de: " + horas * 10);

        Console.WriteLine("Ingrese su monto a pagar: ");
        MontoIngresado = int.Parse(Console.ReadLine());
        TotalPagar = horas * 10;


        if (MontoIngresado < TotalPagar)
        {
            Console.WriteLine("Error, los fondos no son suficientes.");
        }
        else if (MontoIngresado == TotalPagar)
        {
            Console.WriteLine("No se requiere cambio");

        }
        else if (MontoIngresado > TotalPagar)
        {
          cambio = MontoIngresado - TotalPagar;

            if ((cambio / 100) >= 1)
            {
                Billete100 = cambio / 100;
                cambio = cambio % 100;
            }

            if ((cambio / 50) >= 1 )
            {
                Billete50 = cambio / 50;
                cambio = cambio % 50;
            }
            
            if ((cambio / 20) >= 1)
            {
                Billete20 = cambio / 20;
                cambio = cambio % 20;
            }
            
            if ((cambio / 10) >= 1)
            {
                Billete10 = cambio / 10;
                cambio = cambio % 10;
            }
           
            if ((cambio / 5) >= 1)
            {
                Billete5 = cambio / 5;
                cambio = cambio % 5;
            }
            
            if ((cambio / 1) >= 1)
            {
                Billete1 = cambio / 1;
                cambio = cambio % 1;
            }
             Console.WriteLine("Su cambio es de: " + (MontoIngresado - TotalPagar));
             Console.WriteLine("Su cambio se compone de: "+ Billete100 +" Billete $100, " + 
                                                            Billete50 + " billetes de $50, " + 
                                                            Billete20 + " billetes de $20, " + 
                                                            Billete10 + " billetes de $10, " + 
                                                            Billete5 + " billetes de $5, " +
                                                            Billete1 + " billetes de $1");

        }



        


        Console.WriteLine("---------------------------------------------------");




    }
}