﻿//Análisis del problema
//Entradas: Ingreso mensual del vecino (valor numérico), variable booleana llamada multa: true = Tiene multa o false = No tiene multa.
//Procesos: El programa debe determinar el monto del arbitrio a pagar dependiendo del ingreso mensual del vecino, y si tiene multa, el monto de la multa será el doble del monto del arbitrio. El programa debe mostrar el monto del arbitrio a pagar y si tiene multa, también mostrar el monto de la multa a pagar.
//Salidas: El monto del arbitrio a pagar y si tiene multa, el monto de la multa a pagar.
class Ejercicio1
{
    //Inicio de programa Ejercicio 3
    static void Main()
    {
        float IngresoMensual;
        bool multa;
        int arbitrio;
        Console.WriteLine("Coloque su ingreso mensual: ");
        IngresoMensual = float.Parse(Console.ReadLine());

        Console.WriteLine("¿Tiene multa? (true/false): ");
        multa = bool.Parse(Console.ReadLine());



        if (IngresoMensual >= 500.01 && IngresoMensual < 1000.00)
        {
            arbitrio = 10;
        }
        else if (IngresoMensual >= 1000.01 && IngresoMensual < 3000.00)
        {
            arbitrio = 15;
        }
        else if (IngresoMensual >= 3000.01 && IngresoMensual < 6000.00)
        {
            arbitrio = 50;
        }
        else if (IngresoMensual >= 6000.01 && IngresoMensual < 9000.00)
        {
            arbitrio = 75;
        }
        else if (IngresoMensual >= 9000.01 && IngresoMensual < 12000.00)
        {
            arbitrio = 100;
        }

        else if (IngresoMensual >= 12000)
        {
            arbitrio = 150;
        }
        else
        {
            arbitrio = 0;
        }

        if (multa == true)
        {
            Console.WriteLine("El total de arbitrio a pagar es: " + arbitrio);
            Console.WriteLine("El total de multa a pagar es: " + (arbitrio * 2));
        }
        else
        {
            Console.WriteLine("El total de arbitrio a pagar es: " + arbitrio);

        }


        Console.WriteLine("---------------------------------------------------");




    }
}