﻿using System;

class Ejercicio3
{
    static string conversionTemperatura(int celsius, ref double fahrenheit)
    {
        fahrenheit = (celsius * 9 / 5) + 32;

        return "F = " + fahrenheit;
    }


    static void Main()
    {
        Console.WriteLine("Ingrese la temperatura en grados Celsius:");
        int temperatura  = int.Parse(Console.ReadLine());

        double fahrenheit = 0;

        string resultado = conversionTemperatura(temperatura, ref fahrenheit);
        Console.WriteLine("La temperatura en Fahrenheit es: " + fahrenheit);
    }

    

     
}