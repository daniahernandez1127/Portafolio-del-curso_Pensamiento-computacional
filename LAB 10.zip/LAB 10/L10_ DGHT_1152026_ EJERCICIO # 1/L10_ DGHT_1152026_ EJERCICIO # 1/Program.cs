﻿using System;

class Ejercicio1
{
    static void Main()
    {
        Console.WriteLine("Ingrese un número entero positivo:");
        int numero = int.Parse(Console.ReadLine());

        int resultado = sumaDatos(numero);

        Console.WriteLine("La suma de los dígitos es: " + resultado);
    }

    static int sumaDatos(int numero)
    {
        int suma = 0;

        while (numero > 0)
        {
            int digito = numero % 10;
            suma = suma + digito;
            numero = numero / 10;
        }

        return suma;
    }
}