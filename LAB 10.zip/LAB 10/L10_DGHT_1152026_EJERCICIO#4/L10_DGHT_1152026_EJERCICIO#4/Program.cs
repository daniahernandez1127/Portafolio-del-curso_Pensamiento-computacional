﻿using System;

class Ejercicio4
{
    static void Main()
    {

        Console.WriteLine("Bienvenido al Sistema de puntos de estudiante:");
        Console.WriteLine("Ingrese los puntos del estudiante:");
        int puntos = int.Parse(Console.ReadLine());

        Console.WriteLine("Seleccione un numero como opcion para trabajar con los puntos del estudiante:");
        Console.WriteLine("1. Agregar puntos");
        Console.WriteLine("2. Quitar puntos");
        Console.WriteLine("3. Obtener nivel");
        Console.WriteLine("4. Evaluar estado");
        int opcion = int.Parse(Console.ReadLine());

        if (opcion == 1)
        {
            int resultado = agregarPuntos(ref puntos);
            Console.WriteLine($"Puntos actualizados: {resultado}");
        }
        else if (opcion == 2)
        {
            int resultado = quitarPuntos(ref puntos);
            Console.WriteLine($"Puntos actualizados: {resultado}");
        }

        else if (opcion == 3)
        {
            string resultado = obtenerNivel(puntos);
            Console.WriteLine($"Nivel del estudiante: {resultado}");
        }
        else if (opcion == 4)
        {
            string resultado = EvaluarEstado(puntos);
            Console.WriteLine($"Estado del estudiante: {resultado}");
        }




    }

    static int agregarPuntos(ref int puntos)
    {
        int puntosAgregados = 0;

        if (puntos + 10 > 100)
        {
            Console.WriteLine("Los puntos no pueden exceder 100.");

        }

        else
        {
            puntosAgregados = puntos + 10;
        }

        return puntosAgregados;
    }

    static int quitarPuntos(ref int puntos)
    {
        int puntosRestados = 0;
        if (puntos - 7 < 0)
        {
            Console.WriteLine("Los puntos no pueden ser negativos.");
        }
        else
        {
            puntosRestados = puntos - 7;

        }
        return puntosRestados;


    }



    
    static string obtenerNivel(int puntos)
    {
        string estado = "";
        if (puntos >= 80 && puntos <= 100)
        { estado = "Avanzado"; }

        else if (puntos >= 50 && puntos <= 79)
        { estado = "Intermedio"; }

        else if (puntos >= 0 && puntos <= 49)
        { estado = "Básico"; }

        else
        { estado = "Nivel desconocido"; }

        return estado;
    }


    static string EvaluarEstado(int puntos)
    {
        string estado = "";

        if (puntos == 100)
            estado = "Excelente";

        else if (puntos >= 70 && puntos <= 99)
            estado = "Aprobado";

        else if (puntos >= 1 && puntos <= 69)
            estado = "Básico";
        else
        {
            estado = "Estado desconocido";
        }

        return estado;
    }


}