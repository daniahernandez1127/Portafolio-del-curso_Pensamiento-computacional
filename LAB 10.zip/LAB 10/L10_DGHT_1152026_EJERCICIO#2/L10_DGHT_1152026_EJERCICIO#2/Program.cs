﻿using System;

class Ejercicio2
{
    static void Main()
    {
        Console.WriteLine("Ingrese su primer nombre:");
        string nombre1 = Console.ReadLine();

        Console.WriteLine("Ingrese su segundo nombre:");
        string nombre2 = Console.ReadLine();

        Console.WriteLine("Ingrese su primer apellido:");
        string apellido1 = Console.ReadLine();

        Console.WriteLine("Ingrese su segundo apellido:");
        string apellido2 = Console.ReadLine();

        string correo = creacionCorreo(nombre1, nombre2, apellido1, apellido2);
        Console.WriteLine("Su correo institucional es: " + correo);
    }

    static string creacionCorreo(string nombre1, string nombre2, string apellido1, string apellido2)
    {
        char letra1 = nombre1[0];
        char letra2 = nombre2[0];
        char letraApellido2 = apellido2[0];

        string correo = letra1.ToString().ToLower() +
                   letra2.ToString().ToLower() +
                   apellido1.ToLower() +
                   letraApellido2.ToString().ToLower() +
                   "@correo.url.edu.gt";

        return correo;
    }
}